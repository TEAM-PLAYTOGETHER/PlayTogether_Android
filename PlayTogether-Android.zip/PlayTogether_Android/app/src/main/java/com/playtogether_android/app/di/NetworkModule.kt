package com.playtogether_android.app.di

import android.app.Application
import android.content.Context
import com.playtogether_android.BuildConfig
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.GlobalContext
import org.koin.core.logger.Level
import org.koin.dsl.module

val networkModule = module{

}
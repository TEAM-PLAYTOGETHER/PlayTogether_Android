package com.playtogether_android.app.presentation.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.playtogether_android.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
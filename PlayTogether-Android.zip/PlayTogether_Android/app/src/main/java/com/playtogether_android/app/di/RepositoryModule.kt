package com.playtogether_android.app.di

import org.koin.dsl.module

val repositoryModule = module {

}

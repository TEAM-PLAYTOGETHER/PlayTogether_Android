rootProject.name = "PlayTogether-Android"
include(":app")
include(":data")
include(":domain")

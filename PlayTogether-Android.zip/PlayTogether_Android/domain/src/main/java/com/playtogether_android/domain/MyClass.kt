package com.playtogether_android.domain

class MyClass {
}
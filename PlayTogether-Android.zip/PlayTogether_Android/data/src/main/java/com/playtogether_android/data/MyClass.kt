package com.playtogether_android.data

class MyClass {
}